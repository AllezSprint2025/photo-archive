-- ============================================================
-- Photo Store Database Schema
-- Run this in your Supabase SQL Editor
-- ============================================================

-- Albums table
CREATE TABLE albums (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title       TEXT NOT NULL,
  slug        TEXT UNIQUE NOT NULL,
  description TEXT,
  cover_photo_id UUID,
  price_single DECIMAL(10,2) NOT NULL DEFAULT 5.00,
  price_album  DECIMAL(10,2) NOT NULL DEFAULT 25.00,
  is_published BOOLEAN DEFAULT false,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Photos table
CREATE TABLE photos (
  id               UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  album_id         UUID REFERENCES albums(id) ON DELETE CASCADE NOT NULL,
  filename         TEXT NOT NULL,
  original_path    TEXT NOT NULL,
  watermarked_path TEXT NOT NULL,
  sort_order       INTEGER DEFAULT 0,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- Add cover photo FK after photos table exists
ALTER TABLE albums
  ADD CONSTRAINT albums_cover_photo_id_fkey
  FOREIGN KEY (cover_photo_id) REFERENCES photos(id) ON DELETE SET NULL;

-- Orders table
CREATE TABLE orders (
  id                TEXT PRIMARY KEY, -- Stripe session ID
  customer_email    TEXT NOT NULL,
  album_id          UUID REFERENCES albums(id),
  purchase_type     TEXT NOT NULL CHECK (purchase_type IN ('single', 'album')),
  photo_id          UUID REFERENCES photos(id),
  amount_paid       DECIMAL(10,2) NOT NULL,
  promo_code        TEXT,
  status            TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'fulfilled')),
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Download tokens table
CREATE TABLE download_tokens (
  id         UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id   TEXT REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  token      TEXT UNIQUE NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- Storage buckets (run in Supabase Storage settings or SQL)
-- ============================================================
-- Create two buckets in Supabase Storage:
--   1. "originals"   → Private (RLS: service role only)
--   2. "watermarked" → Public

INSERT INTO storage.buckets (id, name, public)
VALUES ('originals', 'originals', false);

INSERT INTO storage.buckets (id, name, public)
VALUES ('watermarked', 'watermarked', true);

-- Allow service role full access to originals
CREATE POLICY "Service role access originals"
ON storage.objects FOR ALL
TO service_role
USING (bucket_id = 'originals');

-- Allow public read on watermarked
CREATE POLICY "Public read watermarked"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'watermarked');

-- Allow service role to write watermarked
CREATE POLICY "Service role write watermarked"
ON storage.objects FOR INSERT
TO service_role
WITH CHECK (bucket_id = 'watermarked');

CREATE POLICY "Service role delete watermarked"
ON storage.objects FOR DELETE
TO service_role
USING (bucket_id = 'watermarked');

-- ============================================================
-- RLS Policies for tables
-- ============================================================
ALTER TABLE albums ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE download_tokens ENABLE ROW LEVEL SECURITY;

-- Public can read published albums and their photos
CREATE POLICY "Public read published albums"
ON albums FOR SELECT TO public
USING (is_published = true);

CREATE POLICY "Public read photos of published albums"
ON photos FOR SELECT TO public
USING (
  album_id IN (SELECT id FROM albums WHERE is_published = true)
);

-- Service role has full access to everything
CREATE POLICY "Service role full access albums"
ON albums FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY "Service role full access photos"
ON photos FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY "Service role full access orders"
ON orders FOR ALL TO service_role USING (true) WITH CHECK (true);

CREATE POLICY "Service role full access download_tokens"
ON download_tokens FOR ALL TO service_role USING (true) WITH CHECK (true);
