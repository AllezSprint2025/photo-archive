'use client'

import { useState } from 'react'
import type { Album, Photo } from '@/types'

interface Props {
  album: Album
  photo: Photo | null
  purchaseType: 'single' | 'album'
  onClose: () => void
}

export default function PurchaseModal({ album, photo, purchaseType, onClose }: Props) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const price = purchaseType === 'album' ? album.price_album : album.price_single
  const label = purchaseType === 'album' ? 'Full Album' : 'Single Photo'

  async function handleCheckout() {
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          albumId: album.id,
          purchaseType,
          photoId: photo?.id,
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error ?? 'Something went wrong. Please try again.')
        setLoading(false)
        return
      }
      window.location.href = data.url
    } catch {
      setError('Network error. Please try again.')
      setLoading(false)
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-md p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-white font-semibold text-lg">Complete Purchase</h2>
          <button
            onClick={onClose}
            className="text-neutral-500 hover:text-white transition-colors text-2xl leading-none"
          >
            ×
          </button>
        </div>

        {/* Order summary */}
        <div className="bg-neutral-800/50 rounded-xl p-4 mb-5">
          <p className="text-neutral-400 text-xs uppercase tracking-wider mb-3">Order Summary</p>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium">{album.title}</p>
              <p className="text-neutral-400 text-sm">{label}</p>
            </div>
            <p className="text-white font-bold text-xl">${price.toFixed(2)}</p>
          </div>
        </div>

        {/* What you get */}
        <div className="mb-5">
          <p className="text-neutral-400 text-sm mb-2">What's included:</p>
          <ul className="space-y-1.5">
            {purchaseType === 'album' ? (
              <>
                <li className="flex items-center gap-2 text-sm text-neutral-300">
                  <span className="text-green-400">✓</span>
                  All {album.photo_count ?? ''} photos in full resolution
                </li>
                <li className="flex items-center gap-2 text-sm text-neutral-300">
                  <span className="text-green-400">✓</span>
                  Delivered as a ZIP file via email
                </li>
              </>
            ) : (
              <li className="flex items-center gap-2 text-sm text-neutral-300">
                <span className="text-green-400">✓</span>
                1 photo in full resolution, delivered via email
              </li>
            )}
            <li className="flex items-center gap-2 text-sm text-neutral-300">
              <span className="text-green-400">✓</span>
              No watermark on downloaded files
            </li>
            <li className="flex items-center gap-2 text-sm text-neutral-300">
              <span className="text-green-400">✓</span>
              Download link valid for 72 hours
            </li>
          </ul>
        </div>

        {error && (
          <p className="text-red-400 text-sm mb-4 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
            {error}
          </p>
        )}

        {/* CTA */}
        <button
          onClick={handleCheckout}
          disabled={loading}
          className="w-full bg-white text-black font-bold py-3.5 rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-60 text-base"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              Redirecting to checkout...
            </span>
          ) : (
            `Pay $${price.toFixed(2)} with Stripe`
          )}
        </button>

        <p className="text-neutral-600 text-xs text-center mt-3">
          Secure checkout via Stripe · Promo codes accepted at checkout
        </p>
      </div>
    </div>
  )
}
