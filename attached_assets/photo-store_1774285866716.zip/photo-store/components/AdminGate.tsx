'use client'

import { useState, useEffect, ReactNode } from 'react'

interface Props {
  children: (secret: string) => ReactNode
}

const SESSION_KEY = 'admin_secret'

export default function AdminGate({ children }: Props) {
  const [secret, setSecret] = useState('')
  const [input, setInput] = useState('')
  const [error, setError] = useState('')
  const [checking, setChecking] = useState(false)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    const stored = sessionStorage.getItem(SESSION_KEY)
    if (stored) setSecret(stored)
    setLoaded(true)
  }, [])

  async function verify(e: React.FormEvent) {
    e.preventDefault()
    setChecking(true)
    setError('')

    // Test the secret against a protected endpoint
    const res = await fetch('/api/admin/albums', {
      headers: { 'x-admin-secret': input },
    })

    if (res.ok) {
      sessionStorage.setItem(SESSION_KEY, input)
      setSecret(input)
    } else {
      setError('Incorrect password.')
    }
    setChecking(false)
  }

  if (!loaded) return null

  if (!secret) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-sm">
          <h1 className="text-2xl font-bold text-white mb-6 text-center">Admin Access</h1>
          <form onSubmit={verify} className="space-y-4">
            <input
              type="password"
              placeholder="Enter admin password"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              autoFocus
              className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-4 py-3 text-white placeholder-neutral-500 focus:outline-none focus:border-neutral-500"
            />
            {error && <p className="text-red-400 text-sm">{error}</p>}
            <button
              type="submit"
              disabled={checking || !input}
              className="w-full bg-white text-black font-semibold py-3 rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50"
            >
              {checking ? 'Checking...' : 'Enter'}
            </button>
          </form>
        </div>
      </div>
    )
  }

  return <>{children(secret)}</>
}
