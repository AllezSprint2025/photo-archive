'use client'

import { useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import type { Album, Photo } from '@/types'
import PurchaseModal from '@/components/PurchaseModal'

interface Props {
  album: Album
  supabaseUrl: string
}

function wmUrl(supabaseUrl: string, path: string) {
  return `${supabaseUrl}/storage/v1/object/public/watermarked/${path}`
}

export default function AlbumClient({ album, supabaseUrl }: Props) {
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalType, setModalType] = useState<'single' | 'album'>('album')
  const [lightboxPhoto, setLightboxPhoto] = useState<Photo | null>(null)

  const photos = album.photos ?? []

  function openPurchase(type: 'single' | 'album', photo?: Photo) {
    setModalType(type)
    setSelectedPhoto(photo ?? null)
    setModalOpen(true)
  }

  return (
    <main className="min-h-screen">
      {/* Header */}
      <header className="border-b border-neutral-800 sticky top-0 z-20 bg-[#0f0f0f]/95 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-4">
          <Link
            href="/"
            className="text-neutral-400 hover:text-white transition-colors text-sm flex items-center gap-1.5"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            All Albums
          </Link>
          <span className="text-neutral-700">/</span>
          <span className="text-white font-medium truncate">{album.title}</span>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        {/* Album header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">{album.title}</h1>
            {album.description && (
              <p className="text-neutral-400 max-w-xl">{album.description}</p>
            )}
            <p className="text-neutral-500 text-sm mt-2">{photos.length} photos</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 sm:items-end">
            <div className="text-right hidden sm:block">
              <p className="text-neutral-400 text-sm">Single photo</p>
              <p className="text-white font-semibold text-lg">${album.price_single.toFixed(2)}</p>
            </div>
            <button
              onClick={() => openPurchase('album')}
              className="bg-white text-black font-semibold px-6 py-3 rounded-lg hover:bg-neutral-200 transition-colors whitespace-nowrap"
            >
              Buy Full Album — ${album.price_album.toFixed(2)}
            </button>
          </div>
        </div>

        {/* Photo grid */}
        {photos.length === 0 ? (
          <div className="text-center py-24 text-neutral-500">No photos in this album yet.</div>
        ) : (
          <div
            className="columns-1 sm:columns-2 md:columns-3 gap-3 space-y-3"
            onContextMenu={(e) => e.preventDefault()}
          >
            {photos.map((photo) => (
              <div
                key={photo.id}
                className="break-inside-avoid group relative rounded-lg overflow-hidden bg-neutral-900 cursor-pointer"
                onClick={() => setLightboxPhoto(photo)}
              >
                <div className="relative">
                  <Image
                    src={wmUrl(supabaseUrl, photo.watermarked_path)}
                    alt=""
                    width={800}
                    height={600}
                    className="w-full h-auto block select-none"
                    draggable={false}
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
                  />
                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-200 flex items-end justify-between p-3 opacity-0 group-hover:opacity-100">
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        openPurchase('single', photo)
                      }}
                      className="bg-white text-black text-xs font-semibold px-3 py-1.5 rounded-md hover:bg-neutral-100 transition-colors"
                    >
                      Buy ${album.price_single.toFixed(2)}
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        setLightboxPhoto(photo)
                      }}
                      className="bg-black/60 text-white text-xs px-3 py-1.5 rounded-md backdrop-blur-sm hover:bg-black/80 transition-colors"
                    >
                      Preview
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Mobile sticky buy album bar */}
        <div className="fixed bottom-0 inset-x-0 sm:hidden bg-[#0f0f0f]/95 border-t border-neutral-800 backdrop-blur-sm p-4 z-20">
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <p className="text-xs text-neutral-400">Single: ${album.price_single.toFixed(2)} · Album: ${album.price_album.toFixed(2)}</p>
            </div>
            <button
              onClick={() => openPurchase('album')}
              className="bg-white text-black font-semibold px-4 py-2.5 rounded-lg hover:bg-neutral-200 transition-colors text-sm whitespace-nowrap"
            >
              Buy Full Album
            </button>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxPhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
          onClick={() => setLightboxPhoto(null)}
        >
          <button
            className="absolute top-4 right-4 text-white/70 hover:text-white text-3xl font-light leading-none"
            onClick={() => setLightboxPhoto(null)}
          >
            ×
          </button>
          <div
            className="relative max-w-5xl max-h-[90vh] w-full"
            onClick={(e) => e.stopPropagation()}
            onContextMenu={(e) => e.preventDefault()}
          >
            <Image
              src={wmUrl(supabaseUrl, lightboxPhoto.watermarked_path)}
              alt=""
              width={1200}
              height={900}
              className="w-full h-auto max-h-[80vh] object-contain select-none"
              draggable={false}
              style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
            />
            <div className="mt-4 flex justify-center gap-3">
              <button
                onClick={() => {
                  setLightboxPhoto(null)
                  openPurchase('single', lightboxPhoto)
                }}
                className="bg-white text-black font-semibold px-6 py-2.5 rounded-lg hover:bg-neutral-200 transition-colors"
              >
                Buy This Photo — ${album.price_single.toFixed(2)}
              </button>
              <button
                onClick={() => {
                  setLightboxPhoto(null)
                  openPurchase('album')
                }}
                className="bg-neutral-800 text-white font-semibold px-6 py-2.5 rounded-lg hover:bg-neutral-700 transition-colors"
              >
                Buy Full Album — ${album.price_album.toFixed(2)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Purchase modal */}
      {modalOpen && (
        <PurchaseModal
          album={album}
          photo={selectedPhoto}
          purchaseType={modalType}
          onClose={() => setModalOpen(false)}
        />
      )}
    </main>
  )
}
