import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { getAlbumBySlug } from '@/lib/db'
import AlbumClient from './AlbumClient'

interface Props {
  params: { slug: string }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const album = await getAlbumBySlug(params.slug)
  if (!album) return {}
  return {
    title: album.title,
    description: album.description ?? `Browse and purchase photos from ${album.title}`,
  }
}

export const revalidate = 60

export default async function AlbumPage({ params }: Props) {
  const album = await getAlbumBySlug(params.slug)
  if (!album) notFound()

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
  return <AlbumClient album={album} supabaseUrl={supabaseUrl} />
}
