import Link from 'next/link'
import Image from 'next/image'
import { getPublishedAlbums } from '@/lib/db'
import type { Album } from '@/types'

export const revalidate = 60 // ISR: revalidate every minute

function getWatermarkedUrl(path: string): string {
  return `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/watermarked/${path}`
}

function AlbumCard({ album }: { album: Album }) {
  const coverUrl = album.cover_photo?.watermarked_path
    ? getWatermarkedUrl(album.cover_photo.watermarked_path)
    : null

  return (
    <Link
      href={`/album/${album.slug}`}
      className="group block rounded-xl overflow-hidden bg-neutral-900 border border-neutral-800 hover:border-neutral-600 transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl"
    >
      {/* Cover image */}
      <div className="relative aspect-[4/3] bg-neutral-800 overflow-hidden">
        {coverUrl ? (
          <Image
            src={coverUrl}
            alt={album.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            draggable={false}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-neutral-600">
            <svg className="w-16 h-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
        )}
        {/* Photo count badge */}
        <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-sm text-white text-xs px-2.5 py-1 rounded-full">
          {album.photo_count ?? 0} photos
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <h2 className="font-semibold text-white text-lg leading-snug mb-1 group-hover:text-purple-300 transition-colors">
          {album.title}
        </h2>
        {album.description && (
          <p className="text-neutral-400 text-sm line-clamp-2 mb-3">{album.description}</p>
        )}
        <div className="flex items-center justify-between">
          <div className="text-sm text-neutral-300">
            <span className="text-white font-medium">${album.price_single.toFixed(2)}</span>
            <span className="text-neutral-500 mx-1.5">/</span>
            <span className="text-white font-medium">${album.price_album.toFixed(2)}</span>
            <span className="text-neutral-500 ml-1 text-xs">album</span>
          </div>
          <span className="text-purple-400 text-sm font-medium group-hover:text-purple-300 transition-colors">
            View →
          </span>
        </div>
      </div>
    </Link>
  )
}

export default async function HomePage() {
  const albums = await getPublishedAlbums()
  const siteName = process.env.NEXT_PUBLIC_SITE_NAME ?? 'Photo Store'

  return (
    <main className="min-h-screen">
      {/* Hero / Header */}
      <header className="border-b border-neutral-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold tracking-tight text-white">{siteName}</h1>
          <p className="text-neutral-400 text-sm hidden sm:block">Professional Photography</p>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
        {albums.length === 0 ? (
          <div className="text-center py-24 text-neutral-500">
            <p className="text-lg">No albums available yet.</p>
            <p className="text-sm mt-2">Check back soon.</p>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-white">All Albums</h2>
              <p className="text-neutral-400 text-sm mt-1">
                {albums.length} album{albums.length !== 1 ? 's' : ''} available
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {albums.map((album) => (
                <AlbumCard key={album.id} album={album} />
              ))}
            </div>
          </>
        )}
      </div>
    </main>
  )
}
