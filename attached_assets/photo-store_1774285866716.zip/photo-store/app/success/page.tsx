import Link from 'next/link'

export default function SuccessPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        {/* Checkmark icon */}
        <div className="w-20 h-20 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>

        <h1 className="text-3xl font-bold text-white mb-3">Payment Successful!</h1>
        <p className="text-neutral-400 mb-6 leading-relaxed">
          Thank you for your purchase. A download link has been sent to your email address.
          Check your inbox (and spam folder) — the link is valid for <strong className="text-white">72 hours</strong>.
        </p>

        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-4 mb-8 text-left">
          <p className="text-sm text-neutral-400 mb-2 font-medium">What happens next:</p>
          <ul className="text-sm text-neutral-300 space-y-1.5">
            <li className="flex items-start gap-2">
              <span className="text-green-400 mt-0.5">✓</span>
              Check your email for a download link
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-400 mt-0.5">✓</span>
              Click the link to download your high-res photos
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-400 mt-0.5">✓</span>
              Save your photos — the link expires in 72 hours
            </li>
          </ul>
        </div>

        <Link
          href="/"
          className="inline-block bg-white text-black font-semibold px-8 py-3 rounded-lg hover:bg-neutral-200 transition-colors"
        >
          Browse More Albums
        </Link>

        <p className="text-neutral-600 text-xs mt-6">
          Didn't receive an email? Check your spam folder or contact us.
        </p>
      </div>
    </main>
  )
}
