import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Admin',
  robots: { index: false, follow: false },
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-neutral-950">
      <nav className="border-b border-neutral-800 bg-neutral-950/95 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="text-white font-bold text-lg">Admin</span>
            <a
              href="/admin"
              className="text-neutral-400 hover:text-white text-sm transition-colors"
            >
              Albums
            </a>
            <a
              href="/admin/upload"
              className="text-neutral-400 hover:text-white text-sm transition-colors"
            >
              Upload
            </a>
          </div>
          <a
            href="/"
            target="_blank"
            className="text-neutral-500 hover:text-white text-xs transition-colors"
          >
            View Site →
          </a>
        </div>
      </nav>
      {children}
    </div>
  )
}
