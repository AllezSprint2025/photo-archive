'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import Image from 'next/image'
import AdminGate from '@/components/AdminGate'
import type { Album, Photo } from '@/types'

interface UploadFile {
  file: File
  preview: string
  status: 'pending' | 'uploading' | 'done' | 'error'
  error?: string
}

function UploadPage({ secret }: { secret: string }) {
  const searchParams = useSearchParams()
  const preselectedAlbumId = searchParams.get('albumId')

  const [albums, setAlbums] = useState<Album[]>([])
  const [selectedAlbumId, setSelectedAlbumId] = useState(preselectedAlbumId ?? '')
  const [files, setFiles] = useState<UploadFile[]>([])
  const [uploading, setUploading] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const [photos, setPhotos] = useState<Photo[]>([])
  const [coverPhotoId, setCoverPhotoId] = useState<string | null>(null)
  const [settingCover, setSettingCover] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    fetch('/api/admin/albums', { headers: { 'x-admin-secret': secret } })
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setAlbums(data)
          if (!selectedAlbumId && data.length > 0) setSelectedAlbumId(data[0].id)
        }
      })
  }, [secret])

  useEffect(() => {
    if (!selectedAlbumId) return
    fetch(`/api/admin/albums/${selectedAlbumId}/photos`, { headers: { 'x-admin-secret': secret } })
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setPhotos(data)
          const album = albums.find((a) => a.id === selectedAlbumId)
          setCoverPhotoId(album?.cover_photo_id ?? null)
        }
      })
  }, [selectedAlbumId, albums])

  function addFiles(newFiles: File[]) {
    const imageFiles = newFiles.filter((f) => f.type.startsWith('image/'))
    const uploads: UploadFile[] = imageFiles.map((f) => ({
      file: f,
      preview: URL.createObjectURL(f),
      status: 'pending',
    }))
    setFiles((prev) => [...prev, ...uploads])
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault()
    setDragOver(false)
    addFiles(Array.from(e.dataTransfer.files))
  }

  function removeFile(index: number) {
    setFiles((prev) => {
      URL.revokeObjectURL(prev[index].preview)
      return prev.filter((_, i) => i !== index)
    })
  }

  async function uploadAll() {
    if (!selectedAlbumId || files.length === 0) return
    setUploading(true)

    // Upload in batches of 3
    const batchSize = 3
    for (let i = 0; i < files.length; i += batchSize) {
      const batch = files.slice(i, i + batchSize)
      const formData = new FormData()
      formData.append('albumId', selectedAlbumId)
      batch.forEach((uf) => formData.append('files', uf.file))

      setFiles((prev) =>
        prev.map((uf, idx) =>
          idx >= i && idx < i + batchSize ? { ...uf, status: 'uploading' } : uf
        )
      )

      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'x-admin-secret': secret },
        body: formData,
      })
      const result = await res.json()

      setFiles((prev) =>
        prev.map((uf, idx) => {
          if (idx < i || idx >= i + batchSize) return uf
          const uploaded = result.uploaded ?? []
          const errors = result.errors ?? []
          if (uploaded.includes(uf.file.name)) return { ...uf, status: 'done' }
          if (errors.includes(uf.file.name)) return { ...uf, status: 'error', error: 'Upload failed' }
          return uf
        })
      )
    }

    setUploading(false)
    // Refresh photo list
    const res = await fetch(`/api/admin/albums/${selectedAlbumId}/photos`, {
      headers: { 'x-admin-secret': secret },
    })
    const data = await res.json()
    if (Array.isArray(data)) setPhotos(data)
    // Clear done files
    setFiles((prev) => prev.filter((f) => f.status !== 'done'))
  }

  async function setCover(photoId: string) {
    setSettingCover(photoId)
    await fetch(`/api/admin/albums/${selectedAlbumId}/cover`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-secret': secret },
      body: JSON.stringify({ photoId }),
    })
    setCoverPhotoId(photoId)
    setAlbums((prev) => prev.map((a) => a.id === selectedAlbumId ? { ...a, cover_photo_id: photoId } : a))
    setSettingCover(null)
  }

  async function deletePhoto(photoId: string) {
    if (!confirm('Delete this photo? This cannot be undone.')) return
    await fetch(`/api/admin/photos/${photoId}`, {
      method: 'DELETE',
      headers: { 'x-admin-secret': secret },
    })
    setPhotos((prev) => prev.filter((p) => p.id !== photoId))
  }

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="text-2xl font-bold text-white mb-6">Upload Photos</h1>

      {/* Album selector */}
      <div className="mb-6">
        <label className="block text-sm text-neutral-400 mb-2">Select Album</label>
        <select
          value={selectedAlbumId}
          onChange={(e) => setSelectedAlbumId(e.target.value)}
          className="bg-neutral-800 border border-neutral-700 text-white rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-neutral-500 w-full sm:w-auto min-w-64"
        >
          {albums.map((a) => (
            <option key={a.id} value={a.id}>
              {a.title}
            </option>
          ))}
        </select>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all mb-6 ${
          dragOver
            ? 'border-white bg-white/5'
            : 'border-neutral-700 hover:border-neutral-500 hover:bg-neutral-900/50'
        }`}
      >
        <svg className="w-12 h-12 text-neutral-600 mx-auto mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        <p className="text-neutral-300 font-medium">Drop photos here or click to browse</p>
        <p className="text-neutral-500 text-sm mt-1">Supports JPEG, PNG • Watermarks generated automatically</p>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={(e) => addFiles(Array.from(e.target.files ?? []))}
        />
      </div>

      {/* Files to upload */}
      {files.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm text-neutral-400">{files.length} file{files.length !== 1 ? 's' : ''} queued</p>
            <div className="flex gap-3">
              <button
                onClick={() => { files.forEach((_, i) => URL.revokeObjectURL(files[i].preview)); setFiles([]) }}
                className="text-sm text-neutral-500 hover:text-white transition-colors"
              >
                Clear all
              </button>
              <button
                onClick={uploadAll}
                disabled={uploading || !selectedAlbumId}
                className="bg-white text-black font-semibold px-5 py-2 rounded-lg hover:bg-neutral-200 transition-colors text-sm disabled:opacity-50"
              >
                {uploading ? 'Uploading...' : `Upload ${files.length} Photo${files.length !== 1 ? 's' : ''}`}
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {files.map((uf, idx) => (
              <div key={idx} className="relative rounded-lg overflow-hidden bg-neutral-900 aspect-square">
                <Image src={uf.preview} alt="" fill className="object-cover" />
                <div className={`absolute inset-0 flex items-center justify-center ${
                  uf.status === 'uploading' ? 'bg-black/50' :
                  uf.status === 'done' ? 'bg-green-500/20' :
                  uf.status === 'error' ? 'bg-red-500/30' : 'bg-black/0'
                }`}>
                  {uf.status === 'uploading' && (
                    <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  )}
                  {uf.status === 'done' && (
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                  {uf.status === 'error' && (
                    <span className="text-red-400 text-xs bg-black/60 px-2 py-1 rounded">Error</span>
                  )}
                </div>
                {uf.status === 'pending' && (
                  <button
                    onClick={(e) => { e.stopPropagation(); removeFile(idx) }}
                    className="absolute top-1 right-1 w-5 h-5 bg-black/70 rounded-full flex items-center justify-center text-white text-xs hover:bg-black transition-colors"
                  >
                    ×
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Existing photos */}
      {photos.length > 0 && (
        <div>
          <h2 className="text-white font-semibold mb-3">
            Album Photos ({photos.length})
            <span className="text-neutral-500 font-normal text-sm ml-2">Click a photo to set as cover</span>
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {photos.map((photo) => (
              <div
                key={photo.id}
                className={`relative rounded-lg overflow-hidden bg-neutral-900 aspect-square group cursor-pointer ${
                  coverPhotoId === photo.id ? 'ring-2 ring-white' : ''
                }`}
                onClick={() => setCover(photo.id)}
              >
                {supabaseUrl && (
                  <Image
                    src={`${supabaseUrl}/storage/v1/object/public/watermarked/${photo.watermarked_path}`}
                    alt=""
                    fill
                    className="object-cover"
                  />
                )}
                {coverPhotoId === photo.id && (
                  <div className="absolute top-1.5 left-1.5 bg-white text-black text-xs font-bold px-1.5 py-0.5 rounded">
                    Cover
                  </div>
                )}
                {settingCover === photo.id && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all flex items-end justify-end p-2 opacity-0 group-hover:opacity-100">
                  <button
                    onClick={(e) => { e.stopPropagation(); deletePhoto(photo.id) }}
                    className="text-xs bg-red-500/80 text-white px-2 py-1 rounded hover:bg-red-500 transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default function UploadPageWrapper() {
  return (
    <AdminGate>
      {(secret) => <UploadPage secret={secret} />}
    </AdminGate>
  )
}
