'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import type { Album } from '@/types'
import AdminGate from '@/components/AdminGate'

function AlbumRow({ album, secret, onRefresh }: { album: Album; secret: string; onRefresh: () => void }) {
  const [loading, setLoading] = useState(false)

  async function togglePublish() {
    setLoading(true)
    await fetch(`/api/admin/albums/${album.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-secret': secret },
      body: JSON.stringify({ is_published: !album.is_published }),
    })
    onRefresh()
    setLoading(false)
  }

  async function deleteAlbum() {
    if (!confirm(`Delete "${album.title}"? This cannot be undone.`)) return
    setLoading(true)
    await fetch(`/api/admin/albums/${album.id}`, {
      method: 'DELETE',
      headers: { 'x-admin-secret': secret },
    })
    onRefresh()
    setLoading(false)
  }

  return (
    <tr className="border-t border-neutral-800 hover:bg-neutral-900/50 transition-colors">
      <td className="px-4 py-4">
        <div>
          <p className="text-white font-medium">{album.title}</p>
          <p className="text-neutral-500 text-xs mt-0.5">/album/{album.slug}</p>
        </div>
      </td>
      <td className="px-4 py-4 text-neutral-400 text-sm">{album.photo_count ?? 0}</td>
      <td className="px-4 py-4 text-neutral-400 text-sm">${album.price_single.toFixed(2)}</td>
      <td className="px-4 py-4 text-neutral-400 text-sm">${album.price_album.toFixed(2)}</td>
      <td className="px-4 py-4">
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
            album.is_published
              ? 'bg-green-500/10 text-green-400 border border-green-500/20'
              : 'bg-neutral-700 text-neutral-400'
          }`}
        >
          {album.is_published ? 'Published' : 'Draft'}
        </span>
      </td>
      <td className="px-4 py-4">
        <div className="flex items-center gap-2">
          <Link
            href={`/admin/upload?albumId=${album.id}`}
            className="text-xs text-blue-400 hover:text-blue-300 transition-colors"
          >
            Upload
          </Link>
          <button
            onClick={togglePublish}
            disabled={loading}
            className="text-xs text-neutral-400 hover:text-white transition-colors disabled:opacity-50"
          >
            {album.is_published ? 'Unpublish' : 'Publish'}
          </button>
          <button
            onClick={deleteAlbum}
            disabled={loading}
            className="text-xs text-red-500 hover:text-red-400 transition-colors disabled:opacity-50"
          >
            Delete
          </button>
        </div>
      </td>
    </tr>
  )
}

function AdminDashboard({ secret }: { secret: string }) {
  const [albums, setAlbums] = useState<Album[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const [form, setForm] = useState({
    title: '',
    slug: '',
    description: '',
    price_single: '5.00',
    price_album: '25.00',
  })
  const [creating, setCreating] = useState(false)
  const [error, setError] = useState('')

  async function fetchAlbums() {
    setLoading(true)
    const res = await fetch('/api/admin/albums', {
      headers: { 'x-admin-secret': secret },
    })
    const data = await res.json()
    setAlbums(Array.isArray(data) ? data : [])
    setLoading(false)
  }

  useEffect(() => { fetchAlbums() }, [])

  function slugify(str: string) {
    return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
  }

  async function createAlbum(e: React.FormEvent) {
    e.preventDefault()
    setCreating(true)
    setError('')
    const res = await fetch('/api/admin/albums', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-secret': secret },
      body: JSON.stringify({
        ...form,
        price_single: parseFloat(form.price_single),
        price_album: parseFloat(form.price_album),
        is_published: false,
      }),
    })
    const data = await res.json()
    if (!res.ok) {
      setError(data.error ?? 'Failed to create album')
    } else {
      setShowCreate(false)
      setForm({ title: '', slug: '', description: '', price_single: '5.00', price_album: '25.00' })
      fetchAlbums()
    }
    setCreating(false)
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">Albums</h1>
        <button
          onClick={() => setShowCreate(true)}
          className="bg-white text-black font-semibold px-4 py-2 rounded-lg hover:bg-neutral-200 transition-colors text-sm"
        >
          + New Album
        </button>
      </div>

      {/* Create album form */}
      {showCreate && (
        <form
          onSubmit={createAlbum}
          className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 mb-6"
        >
          <h2 className="text-white font-semibold mb-4">New Album</h2>
          {error && <p className="text-red-400 text-sm mb-4">{error}</p>}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm text-neutral-400 mb-1">Title *</label>
              <input
                type="text"
                required
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value, slug: slugify(e.target.value) })}
                className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-neutral-500"
                placeholder="Summer Wedding 2024"
              />
            </div>
            <div>
              <label className="block text-sm text-neutral-400 mb-1">URL Slug *</label>
              <input
                type="text"
                required
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: e.target.value })}
                className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-neutral-500"
                placeholder="summer-wedding-2024"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-sm text-neutral-400 mb-1">Description</label>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-neutral-500 resize-none"
                rows={2}
                placeholder="Optional description..."
              />
            </div>
            <div>
              <label className="block text-sm text-neutral-400 mb-1">Single Photo Price ($)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.price_single}
                onChange={(e) => setForm({ ...form, price_single: e.target.value })}
                className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-neutral-500"
              />
            </div>
            <div>
              <label className="block text-sm text-neutral-400 mb-1">Full Album Price ($)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.price_album}
                onChange={(e) => setForm({ ...form, price_album: e.target.value })}
                className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-neutral-500"
              />
            </div>
          </div>
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={creating}
              className="bg-white text-black font-semibold px-5 py-2 rounded-lg hover:bg-neutral-200 transition-colors text-sm disabled:opacity-50"
            >
              {creating ? 'Creating...' : 'Create Album'}
            </button>
            <button
              type="button"
              onClick={() => setShowCreate(false)}
              className="text-neutral-400 hover:text-white text-sm transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Albums table */}
      {loading ? (
        <div className="text-center py-12 text-neutral-500">Loading...</div>
      ) : albums.length === 0 ? (
        <div className="text-center py-12 text-neutral-500">
          No albums yet. Create your first one above.
        </div>
      ) : (
        <div className="rounded-xl border border-neutral-800 overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-neutral-900/50">
                <th className="px-4 py-3 text-left text-xs text-neutral-400 font-medium uppercase tracking-wider">Album</th>
                <th className="px-4 py-3 text-left text-xs text-neutral-400 font-medium uppercase tracking-wider">Photos</th>
                <th className="px-4 py-3 text-left text-xs text-neutral-400 font-medium uppercase tracking-wider">Single</th>
                <th className="px-4 py-3 text-left text-xs text-neutral-400 font-medium uppercase tracking-wider">Album</th>
                <th className="px-4 py-3 text-left text-xs text-neutral-400 font-medium uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs text-neutral-400 font-medium uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody>
              {albums.map((album) => (
                <AlbumRow key={album.id} album={album} secret={secret} onRefresh={fetchAlbums} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export default function AdminPage() {
  return (
    <AdminGate>
      {(secret) => <AdminDashboard secret={secret} />}
    </AdminGate>
  )
}
