import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase-server'

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  if (req.headers.get('x-admin-secret') !== process.env.ADMIN_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const db = createServerClient()

  const { data: photo } = await db
    .from('photos')
    .select('original_path, watermarked_path')
    .eq('id', params.id)
    .single()

  if (photo) {
    await db.storage.from('originals').remove([photo.original_path])
    await db.storage.from('watermarked').remove([photo.watermarked_path])
  }

  const { error } = await db.from('photos').delete().eq('id', params.id)
  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  return NextResponse.json({ success: true })
}
