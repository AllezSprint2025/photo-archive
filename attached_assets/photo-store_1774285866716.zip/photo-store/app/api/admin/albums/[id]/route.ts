import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase-server'

function isAdminAuthorized(req: NextRequest): boolean {
  return req.headers.get('x-admin-secret') === process.env.ADMIN_SECRET
}

// PATCH update album
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  if (!isAdminAuthorized(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const body = await req.json()
  const db = createServerClient()
  const { data, error } = await db
    .from('albums')
    .update(body)
    .eq('id', params.id)
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  return NextResponse.json(data)
}

// DELETE album
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  if (!isAdminAuthorized(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }
  const db = createServerClient()

  // Delete storage files first
  const { data: photos } = await db
    .from('photos')
    .select('original_path, watermarked_path')
    .eq('album_id', params.id)

  if (photos && photos.length > 0) {
    const origPaths = photos.map((p) => p.original_path)
    const wmPaths = photos.map((p) => p.watermarked_path)
    await db.storage.from('originals').remove(origPaths)
    await db.storage.from('watermarked').remove(wmPaths)
  }

  const { error } = await db.from('albums').delete().eq('id', params.id)
  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  return NextResponse.json({ success: true })
}
