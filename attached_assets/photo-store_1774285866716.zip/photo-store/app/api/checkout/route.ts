import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { createServerClient } from '@/lib/supabase-server'
import type { CheckoutPayload } from '@/types'

export async function POST(req: NextRequest) {
  const body = (await req.json()) as CheckoutPayload
  const { albumId, purchaseType, photoId, promoCode } = body

  if (!albumId || !purchaseType) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
  }

  const db = createServerClient()

  // Fetch album
  const { data: album, error: albumError } = await db
    .from('albums')
    .select('id, title, price_single, price_album')
    .eq('id', albumId)
    .eq('is_published', true)
    .single()

  if (albumError || !album) {
    return NextResponse.json({ error: 'Album not found' }, { status: 404 })
  }

  // Determine price
  const unitAmount =
    purchaseType === 'album'
      ? Math.round(album.price_album * 100)
      : Math.round(album.price_single * 100)

  const productName =
    purchaseType === 'album'
      ? `${album.title} — Full Album`
      : `${album.title} — Single Photo`

  const origin = req.headers.get('origin') ?? process.env.NEXT_PUBLIC_SITE_URL

  // Build Stripe session params
  const sessionParams: Parameters<typeof stripe.checkout.sessions.create>[0] = {
    mode: 'payment',
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'usd',
          unit_amount: unitAmount,
          product_data: { name: productName },
        },
        quantity: 1,
      },
    ],
    success_url: `${origin}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/album/${(await getAlbumSlug(db, albumId)) ?? ''}`,
    customer_email: undefined,
    metadata: {
      albumId,
      purchaseType,
      photoId: photoId ?? '',
    },
    allow_promotion_codes: true,
  }

  const session = await stripe.checkout.sessions.create(sessionParams)

  return NextResponse.json({ url: session.url })
}

async function getAlbumSlug(db: ReturnType<typeof import('@/lib/supabase-server').createServerClient>, albumId: string) {
  const { data } = await db
    .from('albums')
    .select('slug')
    .eq('id', albumId)
    .single()
  return data?.slug ?? ''
}
