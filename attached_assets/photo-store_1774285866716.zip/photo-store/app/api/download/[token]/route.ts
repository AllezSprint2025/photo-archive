import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase-server'

export async function GET(
  _req: NextRequest,
  { params }: { params: { token: string } }
) {
  const db = createServerClient()
  const { token } = params

  // Look up the token
  const { data: dlToken, error } = await db
    .from('download_tokens')
    .select('*, order:orders(*)')
    .eq('token', token)
    .single()

  if (error || !dlToken) {
    return new NextResponse('Download link not found.', { status: 404 })
  }

  if (new Date(dlToken.expires_at) < new Date()) {
    return new NextResponse(
      'This download link has expired. Please contact us if you need your files.',
      { status: 410 }
    )
  }

  const order = dlToken.order
  if (!order || order.status === 'pending') {
    return new NextResponse('Order not yet confirmed.', { status: 402 })
  }

  const { albumId, purchaseType, photoId } = {
    albumId: order.album_id as string,
    purchaseType: order.purchase_type as 'single' | 'album',
    photoId: order.photo_id as string | null,
  }

  // Get the list of photos to download
  let photos: { original_path: string; filename: string }[] = []

  if (purchaseType === 'single' && photoId) {
    const { data } = await db
      .from('photos')
      .select('original_path, filename')
      .eq('id', photoId)
      .single()
    if (data) photos = [data]
  } else {
    const { data } = await db
      .from('photos')
      .select('original_path, filename')
      .eq('album_id', albumId)
      .order('sort_order', { ascending: true })
    photos = data ?? []
  }

  if (photos.length === 0) {
    return new NextResponse('No photos found for this order.', { status: 404 })
  }

  // For a single photo, stream it directly
  if (photos.length === 1) {
    const { data: fileData, error: fileError } = await db.storage
      .from('originals')
      .download(photos[0].original_path)

    if (fileError || !fileData) {
      return new NextResponse('File not found.', { status: 404 })
    }

    const arrayBuffer = await fileData.arrayBuffer()

    return new NextResponse(arrayBuffer, {
      headers: {
        'Content-Type': 'image/jpeg',
        'Content-Disposition': `attachment; filename="${photos[0].filename}"`,
      },
    })
  }

  // For multiple photos, create a ZIP archive
  const { default: JSZip } = await import('jszip')
  const zip = new JSZip()

  for (const photo of photos) {
    const { data: fileData, error: fileError } = await db.storage
      .from('originals')
      .download(photo.original_path)

    if (fileError || !fileData) continue

    const buffer = Buffer.from(await fileData.arrayBuffer())
    zip.file(photo.filename, buffer)
  }

  const zipBuffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' })

  // Fetch album title for filename
  const { data: album } = await db
    .from('albums')
    .select('title')
    .eq('id', albumId)
    .single()
  const albumTitle = album?.title?.replace(/[^a-zA-Z0-9_-]/g, '_') ?? 'album'

  return new NextResponse(zipBuffer, {
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${albumTitle}.zip"`,
    },
  })
}
