import { NextResponse } from 'next/server'
import { getAlbumBySlug } from '@/lib/db'

export async function GET(
  _req: Request,
  { params }: { params: { slug: string } }
) {
  const album = await getAlbumBySlug(params.slug)
  if (!album) {
    return NextResponse.json({ error: 'Album not found' }, { status: 404 })
  }
  return NextResponse.json(album)
}
