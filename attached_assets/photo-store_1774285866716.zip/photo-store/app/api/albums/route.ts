import { NextResponse } from 'next/server'
import { getPublishedAlbums } from '@/lib/db'

export async function GET() {
  try {
    const albums = await getPublishedAlbums()
    return NextResponse.json(albums)
  } catch (err) {
    console.error('GET /api/albums error:', err)
    return NextResponse.json({ error: 'Failed to load albums' }, { status: 500 })
  }
}
