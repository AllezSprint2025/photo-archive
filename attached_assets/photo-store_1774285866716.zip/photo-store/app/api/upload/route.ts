import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase-server'
import { applyWatermark } from '@/lib/watermark'
import { v4 as uuidv4 } from 'uuid'

function isAdminAuthorized(req: NextRequest): boolean {
  const secret = req.headers.get('x-admin-secret')
  return secret === process.env.ADMIN_SECRET
}

export async function POST(req: NextRequest) {
  if (!isAdminAuthorized(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const formData = await req.formData()
  const albumId = formData.get('albumId') as string
  const files = formData.getAll('files') as File[]

  if (!albumId || files.length === 0) {
    return NextResponse.json({ error: 'albumId and files are required' }, { status: 400 })
  }

  const db = createServerClient()
  const uploaded: string[] = []
  const errors: string[] = []

  for (const file of files) {
    try {
      const fileId = uuidv4()
      const ext = file.name.split('.').pop()?.toLowerCase() ?? 'jpg'
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
      const originalKey = `${albumId}/${fileId}-${safeName}`
      const watermarkedKey = `${albumId}/${fileId}-wm.jpg`

      const buffer = Buffer.from(await file.arrayBuffer())

      // Upload original to private bucket
      const { error: origError } = await db.storage
        .from('originals')
        .upload(originalKey, buffer, {
          contentType: file.type || 'image/jpeg',
          upsert: false,
        })
      if (origError) throw origError

      // Generate and upload watermarked version
      const watermarked = await applyWatermark(buffer)
      const { error: wmError } = await db.storage
        .from('watermarked')
        .upload(watermarkedKey, watermarked, {
          contentType: 'image/jpeg',
          upsert: false,
        })
      if (wmError) throw wmError

      // Get sort order (count of existing photos in album)
      const { count } = await db
        .from('photos')
        .select('*', { count: 'exact', head: true })
        .eq('album_id', albumId)

      // Save photo record
      const { error: dbError } = await db.from('photos').insert({
        album_id: albumId,
        filename: safeName,
        original_path: originalKey,
        watermarked_path: watermarkedKey,
        sort_order: count ?? 0,
      })
      if (dbError) throw dbError

      uploaded.push(file.name)
    } catch (err) {
      console.error(`Upload error for ${file.name}:`, err)
      errors.push(file.name)
    }
  }

  return NextResponse.json({ uploaded, errors })
}
