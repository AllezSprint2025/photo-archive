import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { createServerClient } from '@/lib/supabase-server'
import { sendDownloadEmail } from '@/lib/email'
import { v4 as uuidv4 } from 'uuid'
import type Stripe from 'stripe'

// Disable body parsing — we need the raw body for Stripe signature verification
export const config = { api: { bodyParser: false } }

export async function POST(req: NextRequest) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')!
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, sig, webhookSecret)
  } catch (err) {
    console.error('Stripe webhook signature error:', err)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session
    await handleCompletedCheckout(session)
  }

  return NextResponse.json({ received: true })
}

async function handleCompletedCheckout(session: Stripe.Checkout.Session) {
  const db = createServerClient()
  const meta = session.metadata ?? {}
  const albumId = meta.albumId
  const purchaseType = meta.purchaseType as 'single' | 'album'
  const photoId = meta.photoId || null
  const customerEmail = session.customer_email ?? session.customer_details?.email ?? ''
  const amountPaid = (session.amount_total ?? 0) / 100

  if (!albumId || !purchaseType || !customerEmail) {
    console.error('Webhook: missing metadata', meta)
    return
  }

  // Create order record
  const { error: orderError } = await db.from('orders').insert({
    id: session.id,
    customer_email: customerEmail,
    album_id: albumId,
    purchase_type: purchaseType,
    photo_id: photoId,
    amount_paid: amountPaid,
    promo_code: session.client_reference_id ?? null,
    status: 'paid',
  })

  if (orderError) {
    // May already exist (duplicate webhook), skip
    if (orderError.code !== '23505') {
      console.error('Webhook: order insert error', orderError)
      return
    }
    return
  }

  // Create a 72-hour download token
  const token = uuidv4()
  const expiresAt = new Date(Date.now() + 72 * 60 * 60 * 1000)

  await db.from('download_tokens').insert({
    order_id: session.id,
    token,
    expires_at: expiresAt.toISOString(),
  })

  // Fetch album info for the email
  const { data: album } = await db
    .from('albums')
    .select('title')
    .eq('id', albumId)
    .single()

  // Count photos if album purchase
  let photoCount: number | undefined
  if (purchaseType === 'album') {
    const { count } = await db
      .from('photos')
      .select('*', { count: 'exact', head: true })
      .eq('album_id', albumId)
    photoCount = count ?? 0
  }

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL
  const downloadUrl = `${siteUrl}/api/download/${token}`

  await sendDownloadEmail({
    to: customerEmail,
    albumTitle: album?.title ?? 'Your Album',
    purchaseType,
    downloadUrl,
    expiresAt,
    photoCount,
  })

  // Mark order fulfilled
  await db.from('orders').update({ status: 'fulfilled' }).eq('id', session.id)
}
