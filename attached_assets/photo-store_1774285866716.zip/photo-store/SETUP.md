# Photo Store — Setup Guide

A complete photo selling platform: upload albums, watermarked previews, Stripe checkout, promo codes, and automated email delivery.

---

## Step 1 — Install Node.js

Download and install Node.js (LTS version) from:
**https://nodejs.org**

Verify installation by opening Terminal and running:
```
node --version
npm --version
```

---

## Step 2 — Install project dependencies

Open Terminal, navigate to this folder, and run:
```
cd "/Users/ajtabak/Documents/Claude Code /photo-store"
npm install
```

This installs all required packages (~2-3 minutes).

---

## Step 3 — Set up Supabase (database + file storage)

1. Go to **https://supabase.com** and create a free account
2. Create a **New Project** (choose a region close to you)
3. Once ready, go to **SQL Editor** in the sidebar
4. Open the file `supabase/schema.sql` and paste the entire contents into the editor
5. Click **Run** — this creates all tables and storage buckets
6. Go to **Settings → API** and copy:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY`

---

## Step 4 — Set up Stripe

1. Log into your Stripe account at **https://dashboard.stripe.com**
2. Go to **Developers → API Keys**
3. Copy your **Publishable key** → `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
4. Copy your **Secret key** → `STRIPE_SECRET_KEY`

### Enable promo codes in Stripe:
- Go to **Products → Coupons** to create discount codes
- Customers enter them at the Stripe checkout page automatically

### Set up the webhook:
After deploying (Step 7), come back here and:
1. Go to **Developers → Webhooks → Add endpoint**
2. URL: `https://yourdomain.com/api/webhooks/stripe`
3. Events to listen to: `checkout.session.completed`
4. Copy the **Signing secret** → `STRIPE_WEBHOOK_SECRET`

For local testing, install the Stripe CLI and run:
```
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

---

## Step 5 — Set up Resend (email delivery)

1. Go to **https://resend.com** and create a free account
2. Go to **API Keys** and create a new key → `RESEND_API_KEY`
3. Go to **Domains** and add your domain (follow DNS verification steps)
4. Set your verified sender: `FROM_EMAIL=hello@yourdomain.com`

> Note: On Resend's free plan you can send to any email but the FROM address must be from a verified domain. During testing you can use `onboarding@resend.dev` as the FROM_EMAIL.

---

## Step 6 — Configure environment variables

1. Copy `.env.example` to `.env.local`:
   ```
   cp .env.example .env.local
   ```
2. Open `.env.local` and fill in all values:
   - All Supabase keys (from Step 3)
   - All Stripe keys (from Step 4)
   - Resend API key and FROM_EMAIL (from Step 5)
   - `NEXT_PUBLIC_SITE_NAME` — your photography brand name
   - `PHOTOGRAPHER_NAME` — shown on watermarks and emails
   - `ADMIN_SECRET` — a strong password for your admin panel

---

## Step 7 — Run locally

```
npm run dev
```

Open **http://localhost:3000** to see your storefront.
Open **http://localhost:3000/admin** to access the admin panel.

---

## Step 8 — Deploy to Vercel (recommended)

1. Push this folder to a GitHub repository
2. Go to **https://vercel.com** → New Project → Import your repo
3. In the Vercel project settings, go to **Environment Variables**
4. Add every variable from your `.env.local` file
5. Deploy — Vercel handles everything automatically

After deploying:
- Update `NEXT_PUBLIC_SITE_URL` to your Vercel URL (e.g. `https://yourname.vercel.app`)
- Add the Stripe webhook endpoint (see Step 4)

---

## How to use the admin panel

Go to `/admin` and enter your `ADMIN_SECRET` password.

### Create an album:
1. Click **+ New Album**
2. Enter title, URL slug, description, and prices
3. Click **Create Album** (starts as Draft — not visible to customers)

### Upload photos:
1. Click **Upload** in the nav
2. Select your album
3. Drag and drop your JPEG files (any number)
4. Watermarks are **automatically generated** on upload
5. Click a photo to set it as the album cover

### Publish an album:
1. On the Albums page, click **Publish** next to your album
2. It will now appear on the homepage

---

## How customers purchase

1. Browse albums on the homepage
2. Click an album to see all watermarked photos
3. Click **Buy This Photo** on a single image, or **Buy Full Album**
4. A modal shows the price and what's included
5. Click **Pay with Stripe** → redirected to Stripe Checkout
6. Enter card details (promo/discount codes accepted here)
7. After payment → automatic email with download link (72-hour expiry)
8. Download original high-resolution photos (no watermark)

---

## File structure overview

```
photo-store/
├── app/
│   ├── page.tsx              # Homepage (album grid)
│   ├── album/[slug]/         # Album view with photos
│   ├── admin/                # Admin panel
│   ├── success/              # Post-purchase confirmation
│   └── api/                  # All API routes
├── components/
│   ├── PurchaseModal.tsx     # Buy single/album modal
│   └── AdminGate.tsx         # Admin password gate
├── lib/
│   ├── watermark.ts          # Sharp watermark logic
│   ├── email.ts              # Resend email templates
│   ├── db.ts                 # Database queries
│   └── stripe.ts             # Stripe client
├── supabase/
│   └── schema.sql            # Run this in Supabase SQL Editor
└── .env.example              # Environment variable template
```

---

## Customizing the watermark

Edit `lib/watermark.ts` to change the watermark appearance:
- `fontSize` — controls text size (default: 7% of shorter image side)
- The SVG template — change font, color, opacity, or add your logo
- `PHOTOGRAPHER_NAME` env var — the text shown on the watermark

## Customizing prices

Edit prices per album in the Admin panel. You can set different prices for each album.

## Stripe promo codes

Create coupons in **Stripe Dashboard → Products → Coupons**. Customers enter them during Stripe Checkout automatically — no extra code needed.
