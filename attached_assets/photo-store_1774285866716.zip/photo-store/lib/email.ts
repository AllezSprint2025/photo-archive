import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY!)

interface SendDownloadEmailParams {
  to: string
  customerName?: string
  albumTitle: string
  purchaseType: 'single' | 'album'
  downloadUrl: string
  expiresAt: Date
  photoCount?: number
}

export async function sendDownloadEmail({
  to,
  customerName,
  albumTitle,
  purchaseType,
  downloadUrl,
  expiresAt,
  photoCount,
}: SendDownloadEmailParams) {
  const greeting = customerName ? `Hi ${customerName},` : 'Hi there,'
  const itemDescription =
    purchaseType === 'album'
      ? `the full <strong>${albumTitle}</strong> album (${photoCount ?? ''} photos)`
      : `your photo from <strong>${albumTitle}</strong>`

  const expiryString = expiresAt.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })

  const fromName = process.env.PHOTOGRAPHER_NAME ?? 'Photo Store'
  const fromEmail = process.env.FROM_EMAIL ?? 'noreply@resend.dev'

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Your Download is Ready</title>
</head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;max-width:600px;width:100%;">

          <!-- Header -->
          <tr>
            <td style="background:#1a1a1a;padding:32px 40px;text-align:center;">
              <p style="margin:0;color:#ffffff;font-size:24px;font-weight:bold;letter-spacing:1px;">
                ${escapeHtml(fromName)}
              </p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:40px;">
              <p style="margin:0 0 16px;font-size:16px;color:#333;">${greeting}</p>
              <p style="margin:0 0 24px;font-size:16px;color:#333;line-height:1.6;">
                Thank you for your purchase! Your download for ${itemDescription} is ready.
              </p>

              <!-- Download Button -->
              <table cellpadding="0" cellspacing="0" style="margin:0 auto 32px;">
                <tr>
                  <td style="background:#1a1a1a;border-radius:8px;padding:0;">
                    <a
                      href="${downloadUrl}"
                      style="display:block;padding:16px 40px;color:#ffffff;text-decoration:none;font-size:16px;font-weight:bold;text-align:center;letter-spacing:0.5px;"
                    >
                      Download Your Photos
                    </a>
                  </td>
                </tr>
              </table>

              <p style="margin:0 0 8px;font-size:14px;color:#666;">
                <strong>Note:</strong> This download link expires on <strong>${expiryString}</strong>.
              </p>
              <p style="margin:0 0 24px;font-size:14px;color:#666;">
                If you have any issues, reply to this email and I'll get back to you as soon as possible.
              </p>

              <hr style="border:none;border-top:1px solid #eee;margin:24px 0;"/>

              <p style="margin:0;font-size:13px;color:#999;line-height:1.6;">
                If the button doesn't work, copy and paste this link into your browser:<br/>
                <a href="${downloadUrl}" style="color:#555;word-break:break-all;">${downloadUrl}</a>
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#f9f9f9;padding:24px 40px;text-align:center;border-top:1px solid #eee;">
              <p style="margin:0;font-size:12px;color:#aaa;">
                © ${new Date().getFullYear()} ${escapeHtml(fromName)}. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `

  await resend.emails.send({
    from: `${fromName} <${fromEmail}>`,
    to,
    subject: `Your photos from ${albumTitle} are ready to download!`,
    html,
  })
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}
