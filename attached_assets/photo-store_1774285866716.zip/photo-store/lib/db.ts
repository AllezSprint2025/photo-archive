import { createServerClient } from './supabase-server'
import type { Album, Photo } from '@/types'

export async function getPublishedAlbums(): Promise<Album[]> {
  const db = createServerClient()
  const { data, error } = await db
    .from('albums')
    .select(`
      *,
      cover_photo:photos!albums_cover_photo_id_fkey (
        id, watermarked_path
      ),
      photos (count)
    `)
    .eq('is_published', true)
    .order('created_at', { ascending: false })

  if (error) throw error

  return (data ?? []).map((album) => ({
    ...album,
    photo_count: album.photos?.[0]?.count ?? 0,
    cover_photo: album.cover_photo ?? undefined,
  }))
}

export async function getAlbumBySlug(slug: string): Promise<Album | null> {
  const db = createServerClient()
  const { data, error } = await db
    .from('albums')
    .select(`
      *,
      photos (
        id, album_id, filename, watermarked_path, original_path, sort_order, created_at
      )
    `)
    .eq('slug', slug)
    .eq('is_published', true)
    .single()

  if (error) return null

  const photos: Photo[] = (data.photos ?? []).sort(
    (a: Photo, b: Photo) => a.sort_order - b.sort_order
  )

  return { ...data, photos }
}

export async function getAllAlbumsAdmin(): Promise<Album[]> {
  const db = createServerClient()
  const { data, error } = await db
    .from('albums')
    .select(`
      *,
      photos (count)
    `)
    .order('created_at', { ascending: false })

  if (error) throw error

  return (data ?? []).map((album) => ({
    ...album,
    photo_count: album.photos?.[0]?.count ?? 0,
  }))
}
