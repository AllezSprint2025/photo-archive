export interface Album {
  id: string
  title: string
  slug: string
  description: string | null
  cover_photo_id: string | null
  price_single: number
  price_album: number
  is_published: boolean
  created_at: string
  cover_photo?: Photo
  photos?: Photo[]
  photo_count?: number
}

export interface Photo {
  id: string
  album_id: string
  filename: string
  original_path: string
  watermarked_path: string
  sort_order: number
  created_at: string
  watermarked_url?: string
}

export interface Order {
  id: string
  customer_email: string
  album_id: string
  purchase_type: 'single' | 'album'
  photo_id: string | null
  amount_paid: number
  promo_code: string | null
  status: 'pending' | 'paid' | 'fulfilled'
  created_at: string
}

export interface DownloadToken {
  id: string
  order_id: string
  token: string
  expires_at: string
  used_at: string | null
  created_at: string
}

export interface CheckoutPayload {
  albumId: string
  purchaseType: 'single' | 'album'
  photoId?: string
  promoCode?: string
}
